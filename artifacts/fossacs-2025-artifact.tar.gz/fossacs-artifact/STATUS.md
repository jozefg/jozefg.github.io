
Functional

  This artifact is a Coq/Rocq formalization which can be built and checked using a single docker
  command. The README contains an extensive list of changes from the base Iris formalization and the
  documentation for the Iris formalization is included to facilitate further exploration and use of
  the codebase.
