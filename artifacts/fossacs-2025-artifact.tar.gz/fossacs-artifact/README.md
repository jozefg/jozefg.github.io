# Artifact for the FoSSaCS paper "Idempotent resources in separation logic".

## Overview

The attached artifact is a Coq/Rocq formalization which formalizes the following result in the
accompanying paper [1]:

> Theorem 3. Every Iris camera in the Iris formalization satisfies the MI axiom.

In particular, this is a forked version of the official Coq formalization of Iris [2] (commit
0203d5ca) which has been modified in the manner described in the paper: the "core" operation has
been removed and all cameras in the formalization have instead been shown to validate the maximal
idempotent axiom.

Since the Iris formalization is a large Coq code base and our changes are comparatively small, we
highlight not the overall structure of the code below, but rather our changes to the Iris
formalization and what they signify (see "Summary of changes" below). For additional precision, we
the file `CHANGES.diff` is the diff of our variant of Iris compared to the version of base Iris
formalization it forks. The README for the Iris formalization itself is preserved in
ORIGINAL_IRIS_README.md and discusses further structure of the codebase, though we summarize all
relevant information below.

Note that the iris-coq formalization is a relatively large Coq project and we have removed several
files from the repository for e.g., the CI server which were irrelevant to our formalization.

[1] https://www.danielgratzer.com/papers/idempotent-resources-in-separation-logic.pdf (preprint)
[2] https://gitlab.mpi-sws.org/iris/iris/

## Build instructions

We have included a docker file allowing this project and all its requirements to be built with a
single command using docker. To install all dependencies and build the Coq code, run the following
command in the main directory (an internet connection is required).

    docker build .

Note: this will download Coq, the dependencies of Iris, and build the entire Iris formalization. On
a standard laptop with four cores, this takes between 30 minutes and an hour.

If this command terminates successfully, all proofs have been successfully checked. Since there is
no single theorem statement (the purpose of this artifact is to demonstrate that the Iris codebase
builds successfully having removed core and replaced it with a new property), the successful
building and checking of the codebase is sufficient. In particular, there is no single theorem
whose assumptions one should check. In light of this, we have provided extensive discussion of the
changes below.

## Summary of changes

### Main changes to definition of `cmra` in Iris.

The main changes to the Iris code base are contained in iris/algebra/cmra.v.

#### Removing core and replacing it with MI axiom
We have removed the part of the existing core definition and the main addition is the property
replacing it: `mixin_cmra_maximum_idemp` in `CMRAMixin`.

In addition, we have extended this change to the various associated structures in the same file:

  - `mixin_cmra_maximum_idemp` (Line 64)
  - `cmra_maximum_idemp` (Line 144)
  - `cmra_maximum_idemp_total` (Line 441)
  - `ra_maximum_idemp` is added to `RAMixin` (a non-stepindexed version) (Line 880)

We have updated the smart constructors (`inj_cmra_mixin_restrict_validity`,
`iso_cmra_mixin_restrict_validity`, and `iso_cmra_mixin`) for various structures to omit references
to `core`. This results in a minor simplifications.

#### Updating `CoreId`

We changed `CoreId` slightly as it made direct reference to the core operation which was
removed. Instead of the previous condition (`|x| ≡ Some x`), we now use `x ≡ x ⋅ x` which is
equivalent in the presence of `cmra_maximum_idemp`. This too has a few associated structures which
we also update:

  - New definition of `CoreId` (Line 151)
  - As a minor addition, we add `op_core_id` (Line 413); a new instance of `CoreId` which is valid
    only in the presence of `cmra_maximum_idemp` and simplifies subsequent proofs.

### Subsequent changes

The bulk of the changes consist of updating every camera in the formalization to (1) remove the
explicit definitions of `core` operations and (2) prove that each camera satisfies the MI
axiom. These changes are local in nature, but there are several dozen cameras which must be
updated. We list the affected files below as well as the line number for the proof of the MI axiom.

  - iris/algebra/cmra.v
    * unitR (Line 935)
    * prodR (Line 993)
    * optionR (Line 1242)
    * discrete_funR (Line 1539)
  - iris/algebra/agree.v (Line 137)
  - iris/algebra/auth.v (no changes necessary, as `auth` inherits structure from `view`)
  - iris/algebra/coPset.v (Line 27, Line 99)
  - iris/algebra/csum.v (Line 217)
  - iris/algebra/dfrac.v (Line 124)
  - iris/algebra/dyn_reservation_map.v (Line 170)
  - iris/algebra/excl.v (Line 79)
  - iris/algebra/frac.v (Line 33)
  - iris/algebra/functions.v (no changes necessary, as ``)
  - iris/algebra/gmap.v (Line 226)
  - iris/algebra/gmultiset.v (Line 28)
  - iris/algebra/gset.v (Line 26)
  - iris/algebra/mra.v (Line 73)
  - iris/algebra/numbers.v (Line 12, Line 72, Line 129, Line 178, Line 214, Line 278)
  - iris/algebra/reservation_map.v (Line 164)
  - iris/algebra/sts.v (Line 433)
  - iris/algebra/ufrac.v (Line 28)
  - iris/algebra/view.v (Line 211)
  - iris_unstable/algebra/list.v (Line 81)
  - tests/ipm_paper.v (Line 137)

The changes to `CoreId` also required that a few small lemmas in the following files be changes. We
include them for completeness, but none of these alterations were substantive.

  - iris/algebra/lib/frac_auth.v
  - iris/algebra/lib/gset_bij.v
  - iris/algebra/lib/mono_Z.v
  - iris/algebra/lib/mono_list.v
  - iris/algebra/lib/mono_nat.v
  - iris/algebra/lib/ufrac_auth.v
  - iris/algebra/lib/max_prefix_list.v
  - iris/algebra/proofmode_classes.v.v
  - iris/algebra/updates.v

A handful of places in the formalization explicitly referred to the `core` operation. We have
changed these to equivalent definitions which avoid invoking `core` directly.

  - iris/base_logic/upred.v (`uPred_persistently_def`, `persistently_ownM_core`)
  - iris/base_logic/bi.v (`persistently_ownM_core`)
  - iris/base_logic/derived.v (small changes to proof scripts)
  - iris/base_logic/own.v (small changes to proof scripts)
  - iris/bi/lib/cmra.v (small changes to proof scripts)

We removed two tests which referred directly to `core`, as they were now unnecessary.

  - tests/proofmode_ascii.v (`test_random_stuff`).
  - tests/proofmode_iris.v (`test_random_stuff`)

These are all the modifed files. In particular iris_heaplang is unchanged.
