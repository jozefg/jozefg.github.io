This artifact was packaged on an x86 machine using Docker 4 [1].

[1] https://www.docker.com/
